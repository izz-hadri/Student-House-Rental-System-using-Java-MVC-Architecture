package rental.controller;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.PrintWriter;
import java.util.LinkedList;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.MultipartConfig;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import javax.servlet.http.Part;

import rental.dao.HouseDAO;
import rental.model.HouseBean;
import rental.model.RenterBean;

/**
 * Servlet implementation class HouseServlet
 */
@WebServlet("/HouseServlet")
@MultipartConfig
public class HouseServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	
	private String forward;
	static HouseDAO dao;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public HouseServlet() {
        super();
        dao = new HouseDAO();
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String action = request.getParameter("action");
		
		if(action.equalsIgnoreCase("getImage")) {
			HouseBean house = HouseDAO.getHouseById(Integer.parseInt(request.getParameter("id")));
			
			if(house.getImage() != null) {
				response.setContentType("image/gif");
				
				OutputStream o = response.getOutputStream();
				o.write(house.getImage());
				o.flush();
				o.close();
				return;
			}
			else
				return;
		}
		else if(action.equalsIgnoreCase("searchAndFilter")) {
			List<HouseBean> searchedHouses = new LinkedList<HouseBean>();
			
			HttpSession session = request.getSession();
			RenterBean loggedRenter = (RenterBean)session.getAttribute("loggedRenter");
	        
			String searchKeyword = request.getParameter("searchKeyword");
			String[] facilities = request.getParameterValues("facilities");
			String sortPrice = request.getParameter("sortPrice");
			
	        if(searchKeyword.equals("") && facilities == null && sortPrice.equals("highestPrice")){
	        	searchedHouses = HouseDAO.getAllHouse(loggedRenter.getIc());
	        }
	        else {
	        	List<HouseBean> houses = HouseDAO.getAllHouseFilter(loggedRenter.getIc(), facilities, sortPrice);
	        	
		        for(HouseBean house : houses){
		            //Initialize default value for flag variable
		            boolean found = false;
		            
		            //Searching process
		            if(!found)
		                found = searchId(house, searchKeyword);
		            if(!found)
		                found = searchAddress(house, searchKeyword);
		            if(!found)
		                found = searchArea(house, searchKeyword);
		            if(!found)
		                found = searchPrice(house, searchKeyword);
		            if(!found)
		                found = searchContract(house, searchKeyword);
		            if(!found)
		                found = searchCapacity(house, searchKeyword);
		            if(!found)
		                found = searchLandlordIc(house, searchKeyword);
		            
		            //Add or remove searched house
		            if(found)
		            	searchedHouses.add(house);
		            else
		            	searchedHouses.remove(house);
		        }
	        }
	        request.setAttribute("searchKeyword", searchKeyword);
	        request.setAttribute("facilities", facilities);
	        request.setAttribute("sortPrice", sortPrice);
	        request.setAttribute("houses", searchedHouses);
	        
	        forward = "renter-home-searched.jsp";
		}
		else if(action.equalsIgnoreCase("add")) {
			HouseBean house = new HouseBean();
			
			house.setAddress(request.getParameter("address"));
			house.setArea(request.getParameter("areas"));
			house.setPrice(Float.parseFloat(request.getParameter("price")));
			house.setContract(Integer.parseInt(request.getParameter("contract")));
			house.setCapacity(Integer.parseInt(request.getParameter("capacity")));
			house.setDescription(request.getParameter("description"));
			house.setLandlordIc(request.getParameter("ic"));
			
			//Set the image
			Part imagePart = request.getPart("image");
			InputStream image = null;
	        if (imagePart != null)
	        	image = imagePart.getInputStream();
	        
			dao.add(house, image);
			
			forward = "landlord-house.jsp";
		}
		else if(action.equalsIgnoreCase("delete")) {
			int id = Integer.parseInt(request.getParameter("id"));
			
			if(!dao.checkHouseIsRented(id))
				dao.delete(id);
			else {
				response.setContentType("text/html");	
				
				PrintWriter out = response.getWriter();
				out.write("<script>");
				out.write("alert('Cannot Delete House! The house is currently rented or pending');");
				out.write("location='landlord-house.jsp';");
				out.write("</script>");
				return;
			}
			
			forward = "landlord-house.jsp";
		}
		else if(action.equalsIgnoreCase("update")) {
			HouseBean house = new HouseBean();
			
			house.setId(Integer.parseInt(request.getParameter("id")));
			house.setAddress(request.getParameter("address"));
			house.setArea(request.getParameter("areas"));
			house.setPrice(Float.parseFloat(request.getParameter("price")));
			house.setContract(Integer.parseInt(request.getParameter("contract")));
			house.setCapacity(Integer.parseInt(request.getParameter("capacity")));
			house.setDescription(request.getParameter("description"));
			
			dao.update(house);
			
			forward = "landlord-house-details.jsp?id=" + house.getId();
		}
		
		RequestDispatcher view = request.getRequestDispatcher(forward);
		view.forward(request, response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doGet(request, response);
	}
	
	//Extra Method
	//Searching Method
    private boolean searchId(HouseBean house, String searchKeyword) {
        try {
	        //Search the keyword
	        if(searchKeyword.equalsIgnoreCase((""+house.getId()).substring(0, searchKeyword.length())))
	            return true;
        }
        catch(IndexOutOfBoundsException ex) {}
        return false;
    }
    
    private boolean searchAddress(HouseBean house, String searchKeyword) {
        try {
	        //Search the keyword
	        if(searchKeyword.equalsIgnoreCase(house.getAddress().substring(0, searchKeyword.length())))
	            return true;
        }
        catch(IndexOutOfBoundsException ex) {}
        return false;
    }
    
    private boolean searchArea(HouseBean house, String searchKeyword) {
        try {
	        //Search the keyword
	        if(searchKeyword.equalsIgnoreCase(house.getArea().substring(0, searchKeyword.length())))
	            return true;
        }
        catch(IndexOutOfBoundsException ex) {}
        return false;
    }
    
    private boolean searchPrice(HouseBean house, String searchKeyword) {
        try {
	        //Search the keyword
	        if(searchKeyword.equalsIgnoreCase((""+house.getPrice()).substring(0, searchKeyword.length())))
	            return true;
        }
        catch(IndexOutOfBoundsException ex) {}
        return false;
    }
    
    private boolean searchContract(HouseBean house, String searchKeyword) {
        try {
	        //Search the keyword
	        if(searchKeyword.equalsIgnoreCase((""+house.getContract()).substring(0, searchKeyword.length())))
	            return true;
        }
        catch(IndexOutOfBoundsException ex) {}
        return false;
    }
    
    private boolean searchCapacity(HouseBean house, String searchKeyword) {
        try {
	        //Search the keyword
	        if(searchKeyword.equalsIgnoreCase((""+house.getCapacity()).substring(0, searchKeyword.length())))
	            return true;
        }
        catch(IndexOutOfBoundsException ex) {}
        return false;
    }
    
    private boolean searchLandlordIc(HouseBean house, String searchKeyword) {
        try {
	        //Search the keyword
	        if(searchKeyword.equalsIgnoreCase(house.getLandlordIc().substring(0, searchKeyword.length())))
	            return true;
        }
        catch(IndexOutOfBoundsException ex) {}
        return false;
    }
}
