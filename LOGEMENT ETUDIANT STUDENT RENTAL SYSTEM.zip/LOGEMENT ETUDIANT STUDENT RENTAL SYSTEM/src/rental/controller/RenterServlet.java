package rental.controller;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.MultipartConfig;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import javax.servlet.http.Part;

import rental.dao.RenterDAO;
import rental.model.RenterBean;

/**
 * Servlet implementation class RenterServlet
 */
@WebServlet("/RenterServlet")
@MultipartConfig
public class RenterServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	
	private String forward;
	static RenterDAO dao;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public RenterServlet() {
        super();
        dao = new RenterDAO();
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String action = request.getParameter("action");
		
		if(action.equalsIgnoreCase("signUp")) {
			//Sign Up
			RenterBean renter = new RenterBean();
			
			renter.setIc(request.getParameter("ic"));
			renter.setName(request.getParameter("name"));
			renter.setEmail(request.getParameter("email"));
			renter.setAddress(request.getParameter("address"));
			renter.setPhoneNumber(request.getParameter("phoneNumber"));
			renter.setPassword(request.getParameter("password"));
			renter.setGender(request.getParameter("gender"));
			
			boolean icValidate = dao.icValidate(renter.getIc());
			boolean emailValidate = dao.emailValidate(renter.getEmail());
			
			if(icValidate && emailValidate) {
				dao.add(renter);
				
				forward = "renter-login.html"; //Sign Up Successfully
			}
			else {
				request.setAttribute("ic", renter.getIc());
				request.setAttribute("name", renter.getName());
				request.setAttribute("email", renter.getEmail());
				request.setAttribute("address", renter.getAddress());
				request.setAttribute("phoneNumber", renter.getPhoneNumber());
				request.setAttribute("icValidate", icValidate);
				request.setAttribute("emailValidate", emailValidate);
				request.setAttribute("gender", renter.getGender());
				
				forward = "renter-signup-error.jsp"; //Sign Up Failed - existed IC or Email
			}
		}
		else if(action.equalsIgnoreCase("login")) {
			//Login
			RenterBean renter = null;
			
			String ic = request.getParameter("ic");
			String password = request.getParameter("password");
			
			if((renter = dao.login(ic, password)) != null) {
				HttpSession session = request.getSession();
				session.setAttribute("loggedRenter", renter);
				
				forward = "renter-home.jsp"; //Login Successfully
			}
			else 
				forward = "renter-login-error.html"; //Login Failed - wrong IC or Password
		}
		else if(action.equalsIgnoreCase("logout")) {
			//Logout
			HttpSession session = request.getSession();
			session.invalidate();
			
			forward = "index.html"; //Logout Successfully
		}
		else if(action.equalsIgnoreCase("updateRenterProfile")) {
			//Update Profile
			RenterBean renter = new RenterBean();
			boolean emailValidate = true;
			
			renter.setIc(request.getParameter("ic"));
			renter.setName(request.getParameter("name"));
			renter.setEmail(request.getParameter("email"));
			renter.setAddress(request.getParameter("address"));
			renter.setPhoneNumber(request.getParameter("phoneNumber"));
			renter.setPassword(!request.getParameter("newPassword").equals("") ? request.getParameter("newPassword") : request.getParameter("password"));
			renter.setGender(request.getParameter("gender"));
			
			//Set the image
			Part imagePart = request.getPart("image");
			InputStream newImage = null;
	        if (imagePart != null)
	        	newImage = imagePart.getInputStream();
			
			HttpSession session = request.getSession();
			RenterBean loggedRenter = (RenterBean)session.getAttribute("loggedRenter");
			
			if(!loggedRenter.getEmail().equals(renter.getEmail()))
				emailValidate = dao.emailValidate(renter.getEmail()); //Validate the email if email is changed
			
			if(emailValidate) {
				dao.update(renter, newImage);
				session.setAttribute("loggedRenter", RenterDAO.getRenterByIc(renter.getIc())); //Update the logged renter with new information
				
				forward = "renter-profile.jsp"; //Update Profile Successfully
			}
			else {
				request.setAttribute("ic", renter.getIc());
				request.setAttribute("name", renter.getName());
				request.setAttribute("email", renter.getEmail());
				request.setAttribute("address", renter.getAddress());
				request.setAttribute("phoneNumber", renter.getPhoneNumber());
				request.setAttribute("password", renter.getPassword());
				request.setAttribute("emailValidate", emailValidate);
				request.setAttribute("gender", renter.getGender());
				
				forward = "renter-profile-error.jsp"; //Update Profile Failed - existed Email
			}
		}
		else if(action.equalsIgnoreCase("getImage")) {
			HttpSession session = request.getSession();
			RenterBean loggedRenter = (RenterBean)session.getAttribute("loggedRenter");
			
			if(loggedRenter.getImage() != null) {
				response.setContentType("image/gif");
				
				OutputStream o = response.getOutputStream();
				o.write(loggedRenter.getImage());
				o.flush();
				o.close();
				return;
			}else
				return;
		}
		
		RequestDispatcher view = request.getRequestDispatcher(forward);
		view.forward(request, response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doGet(request, response);
	}
}
