package rental.controller;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import rental.dao.PaymentDAO;

/**
 * Servlet implementation class PaymentServlet
 */
@WebServlet("/PaymentServlet")
public class PaymentServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	
	private String forward;
	private PaymentDAO dao; 
    /**
     * @see HttpServlet#HttpServlet()
     */
    public PaymentServlet() {
        super();
        dao = new PaymentDAO();
        
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String action = request.getParameter("action");
		
		
		if(action.equalsIgnoreCase("verify")) {
			String ric = request.getParameter("ric");
			String hid = request.getParameter("hid");
			String pid = request.getParameter("pid");
			int rentalId = Integer.parseInt(request.getParameter("rentalId"));
			
			if(dao.verifyPayment(ric,hid,pid)) {
				forward = "landlord-renter-details-payment-details.jsp?renterIc="+ric+"&rentalId="+rentalId;		
			}	
		}
		
		RequestDispatcher view = request.getRequestDispatcher(forward);
		view.forward(request, response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doGet(request, response);
	}

}
