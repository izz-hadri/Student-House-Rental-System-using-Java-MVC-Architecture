package rental.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import rental.dao.HouseDAO;
import rental.dao.PaymentDAO;
import rental.dao.RentalDAO;
import rental.model.HouseBean;
import rental.model.PaymentBean;
import rental.model.RentalBean;

/**
 * Servlet implementation class RentalServlet
 */
@WebServlet("/RentalServlet")
public class RentalServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	
	private String forward;
	static RentalDAO dao;
	static PaymentDAO daoP;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public RentalServlet() {
        super();
        dao = new RentalDAO();
        daoP = new PaymentDAO();
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String action = request.getParameter("action");
		
		if(action.equalsIgnoreCase("rentHouse")) {
			//Rent House
			RentalBean rental = new RentalBean();
			
			rental.setRegisterDate(new Date());
			rental.setExpiredDate(addMonth(new Date(), Integer.parseInt(request.getParameter("contract"))));
			rental.setStatus("Pending");
			rental.setRenterIc(request.getParameter("renterIc"));
			rental.setHouseId(Integer.parseInt(request.getParameter("houseId")));
			
			dao.add(rental);
			
			forward = "renter-home.jsp";
		}
		else if(action.equalsIgnoreCase("extend")) {
			Date expiredDate = new Date();
			try {
				expiredDate = new SimpleDateFormat("yyyy-MM-dd").parse((request.getParameter("expiredDate")));
			} catch (ParseException e) {
				e.printStackTrace();
			}
			int contract = Integer.parseInt(request.getParameter("contract"));
			int id = Integer.parseInt(request.getParameter("rentalId"));
			
			dao.update(addMonth(expiredDate, contract), id);
			
			forward = "renter-rented-house.jsp";
		}
		else if(action.equalsIgnoreCase("cancel")) {
			int rentalId = Integer.parseInt(request.getParameter("rentalId"));
			
			dao.delete(rentalId);
			
			forward = "renter-rented-house.jsp";
		}
		else if(action.equalsIgnoreCase("disapprove")) {
			int rentalId = Integer.parseInt(request.getParameter("rentalId"));
			
			dao.delete(rentalId);
			
			forward = "landlord-renter-approval.jsp";
		}
		else if(action.equalsIgnoreCase("approve")) {
			int rentalId = Integer.parseInt(request.getParameter("rentalId"));
			int houseId	= Integer.parseInt(request.getParameter("houseId"));
			
			if(dao.validateApprove(houseId)) {
				dao.approve(rentalId);
			
				RentalBean rental = RentalDAO.getRentalById(rentalId);
				HouseBean house = HouseDAO.getHouseById(rental.getHouseId());
				
				PaymentBean payment = new PaymentBean();
				payment.setHouseId(rental.getHouseId());
				payment.setLandLordIc(house.getLandlordIc());
				payment.setPrice(house.getPrice());
				payment.setRenterIc(rental.getRenterIc());
				
				daoP.addPaymentDate(payment);
			}
			else {
				response.setContentType("text/html");	
				
				PrintWriter out = response.getWriter();
				out.write("<script>");
				out.write("alert('Cannot Approve! The house is currently rented');");
				out.write("location='landlord-renter-approval.jsp';");
				out.write("</script>");
			}
			
			forward = "landlord-renter-approval.jsp";
		}
		
		RequestDispatcher view = request.getRequestDispatcher(forward);
		view.forward(request, response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doGet(request, response);
	}
	
	//Extra Method
	private Date addMonth(Date date, int month) {
		Calendar calendar = Calendar.getInstance();
		
		calendar.setTime(date);
		calendar.add(Calendar.MONTH, month);
		
		return calendar.getTime();
	}

}
