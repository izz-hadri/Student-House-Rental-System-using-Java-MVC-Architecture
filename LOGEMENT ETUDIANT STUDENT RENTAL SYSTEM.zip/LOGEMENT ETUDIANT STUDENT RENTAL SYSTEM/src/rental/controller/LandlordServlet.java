package rental.controller;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import rental.dao.LandlordDAO;
import rental.model.LandlordBean;

/**
 * Servlet implementation class LandlordServlet
 */
@WebServlet("/LandlordServlet")
public class LandlordServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	private String forward;
	private LandlordDAO dao;

	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public LandlordServlet() {
		super();
		dao = new LandlordDAO();
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String action = request.getParameter("action");

		if(action.equalsIgnoreCase("login")) { 
			//LOGIN
			LandlordBean landlord = null;
			
			String ic = request.getParameter("ic");
			String password =request.getParameter("password");

			if((landlord = dao.login(ic, password)) != null) {
				HttpSession session = request.getSession();
				
				session.setAttribute("ic",landlord.getIc()); 
				session.setAttribute("name",landlord.getName());
				session.setAttribute("email",landlord.getEmail());
				
				forward = "landlord-house.jsp"; //Login Successfully
			}
			else 
				forward = "landlord-login-error.html"; //Login Failed - wrong IC or Password
		}
		else if(action.equalsIgnoreCase("signUp")) {
			LandlordBean landlord = new LandlordBean();
			
			landlord.setIc(request.getParameter("ic"));
			landlord.setName(request.getParameter("name"));
			landlord.setEmail(request.getParameter("email"));		
			landlord.setPhoneNumber(request.getParameter("phone"));
			landlord.setPassword(request.getParameter("password"));

			boolean icValidate = dao.icValidate(landlord.getIc());
			boolean emailValidate = dao.emailValidate(landlord.getEmail());
			
			if(icValidate && emailValidate) {
				dao.add(landlord);
				
				forward = "landlord-login.html"; //Sign Up Successfully
			}
			else {
				request.setAttribute("ic", landlord.getIc());
				request.setAttribute("name", landlord.getName());
				request.setAttribute("email", landlord.getEmail());
				request.setAttribute("phoneNumber", landlord.getPhoneNumber());
				request.setAttribute("icValidate", icValidate);
				request.setAttribute("emailValidate", emailValidate);
				
				forward = "landlord-signup-error.jsp"; //Sign Up Failed - existed IC or Email
			}
		}
		else if(action.equalsIgnoreCase("logout")) {
			//Logout
			HttpSession session = request.getSession();
			session.invalidate();
			
			forward = "index.html"; //Logout Successfully
		}
		else if(action.equals("update")) {
			LandlordBean landlord = new LandlordBean();
			HttpSession session = request.getSession();
			boolean emailValidate = true;
			
			landlord.setIc(request.getParameter("ic"));
			landlord.setName(request.getParameter("name"));
			landlord.setEmail(request.getParameter("email"));		
			landlord.setPhoneNumber(request.getParameter("phonenum"));
			landlord.setAccountNumber(request.getParameter("accno"));
			landlord.setBankName(request.getParameter("bankname"));
			landlord.setPassword(!request.getParameter("newPassword").equals("") ? request.getParameter("newPassword") : request.getParameter("pass1"));
			
			String oldEmail = (String)session.getAttribute("email");
			if(!oldEmail.equals(landlord.getEmail()))
				emailValidate = dao.emailValidate(landlord.getEmail());
			
			if(emailValidate) {
				dao.update(landlord);
				
				session.setAttribute("name", landlord.getName());
				session.setAttribute("email", landlord.getEmail());
				
				forward = "landlord-profile.jsp"; //Update Successfully
			}
			else {
				request.setAttribute("ic", landlord.getIc());
				request.setAttribute("name", landlord.getName());
				request.setAttribute("email", landlord.getEmail());
				request.setAttribute("phoneNumber", landlord.getPhoneNumber());
				request.setAttribute("bankName", landlord.getBankName());
				request.setAttribute("accountNumber", landlord.getAccountNumber());
				request.setAttribute("emailValidate", emailValidate);
				request.setAttribute("password", landlord.getPassword());
				
				forward = "landlord-profile-error.jsp"; //Update Failed - existed Email
			}
		}
		
		RequestDispatcher view = request.getRequestDispatcher(forward);
		view.forward(request, response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doGet(request, response);
	}
}
