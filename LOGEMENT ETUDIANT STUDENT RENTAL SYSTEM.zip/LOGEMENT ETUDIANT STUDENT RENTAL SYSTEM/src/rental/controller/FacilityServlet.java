package rental.controller;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import rental.dao.FacilityDAO;
import rental.model.FacilityBean;
/**
 * Servlet implementation class FacilityServlet
 */
@WebServlet("/FacilityServlet")
public class FacilityServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	
	private String forward;
	static FacilityDAO dao;
    /**
     * @see HttpServlet#HttpServlet()
     */
    public FacilityServlet() {
        super();
        dao = new FacilityDAO();
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String action = request.getParameter("action");
		
		if(action.equalsIgnoreCase("add")) {
			FacilityBean facility = new FacilityBean();
			int houseId = Integer.parseInt(request.getParameter("houseId"));
			
			facility.setName(request.getParameter("type"));
			facility.setQuantity(Integer.parseInt(request.getParameter("quantity")));
			
			dao.add(facility, houseId);
			
			forward = "landlord-house-details.jsp?id=" + houseId;
		}
		else if(action.equalsIgnoreCase("delete")) {
			int id = Integer.parseInt(request.getParameter("id"));
			int houseId = Integer.parseInt(request.getParameter("houseId"));
			
			dao.delete(id);
			
			forward = "landlord-house-details.jsp?id=" + houseId;
		}
		
		RequestDispatcher view = request.getRequestDispatcher(forward);
		view.forward(request, response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doGet(request, response);
	}

}
