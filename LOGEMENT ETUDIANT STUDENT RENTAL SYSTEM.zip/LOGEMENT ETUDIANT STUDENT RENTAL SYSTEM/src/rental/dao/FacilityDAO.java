package rental.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.LinkedList;
import java.util.List;

import rental.connection.ConnectionManager;
import rental.model.FacilityBean;

public class FacilityDAO {
	static Connection con = null;
	static ResultSet rs = null;
	static PreparedStatement ps = null;
	static Statement stmt = null;
	
	static int id, quantity, houseId;
	static String name;
	
	public static List<FacilityBean> getAllFacilityByHouseId(int houseId) {
		List<FacilityBean> facilities = new LinkedList<FacilityBean>();
		
		try {
			con = ConnectionManager.getConnection();

			ps = con.prepareStatement(
					"SELECT * FROM FACILITY "
					+ "JOIN HOUSE "
					+ "USING (HOUSE_ID) "
					+ "WHERE HOUSE_ID=?"
				);
			
			ps.setInt(1, houseId);
			rs = ps.executeQuery();
			
			while(rs.next()) {
				FacilityBean facility = new FacilityBean();
				
				facility.setId(rs.getInt("FACILITY_ID"));
				facility.setName(rs.getString("FACILITY_NAME"));
				facility.setQuantity(rs.getInt("FACILITY_QUANTITY"));
				facility.setHouseId(rs.getInt("HOUSE_ID"));
				
				facilities.add(facility);
			}
			
			rs.close();
			ps.close();
			con.close();
		}
		catch(SQLException ex) {
			ex.printStackTrace();
		}
		return facilities;
	}
	
	public void add(FacilityBean bean, int houseId) {
		quantity = bean.getQuantity();
		name = bean.getName();
		
		try {
			con = ConnectionManager.getConnection();

			ps = con.prepareStatement("INSERT INTO FACILITY (FACILITY_NAME,FACILITY_QUANTITY,HOUSE_ID) VALUES(?,?,?)");

			ps.setString(1, name);
			ps.setInt(2, quantity);
			ps.setInt(3, houseId);
			ps.executeUpdate();
		}
		catch(SQLException ex) {
			ex.printStackTrace();
		}
		finally {
			if (ps != null) {
				try {
					ps.close();
				} catch (Exception e) {
				}
				ps = null;
			}
			if (con != null) {
				try {
					con.close();
				} catch (Exception e) {
				}
				con = null;
			}
		}
	}
	
	public void delete(int id) {
		try {
			con = ConnectionManager.getConnection();

			ps = con.prepareStatement(
					"DELETE FACILITY WHERE FACILITY_ID=?"
				);
			
			ps.setInt(1, id);
			ps.executeUpdate();
			
			ps.close();
			con.close();
		}
		catch(SQLException ex) {
			ex.printStackTrace();
		}
	}
}
