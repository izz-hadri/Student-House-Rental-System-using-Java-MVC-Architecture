package rental.dao;

import java.io.IOException;
import java.io.InputStream;
import java.sql.Blob;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import rental.connection.ConnectionManager;
import rental.model.RenterBean;

public class RenterDAO {
	static Connection con = null;
	static ResultSet rs = null;
	static PreparedStatement ps = null;
	static Statement stmt = null;
	
	static String ic, name, email, address, phoneNumber, password, gender;
	static byte[] image;
	
	public void add(RenterBean bean) {
		ic = bean.getIc();
		name = bean.getName();
		email = bean.getEmail();
		address = bean.getAddress();
		phoneNumber = bean.getPhoneNumber();
		password = bean.getPassword();
		gender = bean.getGender();
		image = bean.getImage();
		
		try {
			con = ConnectionManager.getConnection();

			ps = con.prepareStatement(
					"INSERT INTO RENTER VALUES(?,?,?,?,?,?,?,?)"
				);
			
			ps.setString(1, ic);
			ps.setString(2, name);
			ps.setString(3, email);
			ps.setString(4, address);
			ps.setString(5, phoneNumber);
			ps.setString(6, password);
			ps.setString(7, gender);
			ps.setBytes(8, image);
			ps.executeUpdate();
			
			ps.close();
			con.close();
		}
		catch(SQLException ex) {
			ex.printStackTrace();
		}
	}
	
	public void update(RenterBean bean, InputStream image) {
		ic = bean.getIc();
		name = bean.getName();
		email = bean.getEmail();
		address = bean.getAddress();
		phoneNumber = bean.getPhoneNumber();
		password = bean.getPassword();
		gender = bean.getGender();
		
		try {
			con = ConnectionManager.getConnection();

			ps = con.prepareStatement(
					"UPDATE RENTER "
					+ "SET RENTER_NAME=?, RENTER_EMAIL=?, RENTER_ADDRESS=?, RENTER_PHONENUMBER=?, RENTER_PASSWORD=?, RENTER_GENDER=?, RENTER_IMAGE=?"
					+ "WHERE RENTER_IC=?"
				);
			
			ps.setString(1, name);
			ps.setString(2, email);
			ps.setString(3, address);
			ps.setString(4, phoneNumber);
			ps.setString(5, password);
			ps.setString(6, gender);
			ps.setBlob(7, image);
			ps.setString(8, ic);
			ps.executeUpdate();
			
			ps.close();
			con.close();
		}
		catch(SQLException ex) {
			ex.printStackTrace();
		}
	}
	
	public RenterBean login(String ic, String password) {
		RenterBean renter = null;
		
		try {
			con = ConnectionManager.getConnection();

			ps = con.prepareStatement(
					"SELECT * "
					+ "FROM RENTER "
					+ "WHERE RENTER_IC LIKE ? AND RENTER_PASSWORD LIKE ?"
				);
			
			ps.setString(1, ic);
			ps.setString(2, password);
			rs = ps.executeQuery();
			
			if(rs.next()) {
				renter = new RenterBean();
				
				renter.setIc(rs.getString("RENTER_IC"));
				renter.setName(rs.getString("RENTER_NAME"));
				renter.setEmail(rs.getString("RENTER_EMAIL"));
				renter.setAddress(rs.getString("RENTER_ADDRESS"));
				renter.setPhoneNumber(rs.getString("RENTER_PHONENUMBER"));
				renter.setPassword(rs.getString("RENTER_PASSWORD"));
				renter.setGender(rs.getString("RENTER_GENDER"));
				
				Blob blob = rs.getBlob("RENTER_IMAGE");
				if(blob != null) 
					renter.setImage(blob.getBytes(1, (int)blob.length()));
				else
					renter.setImage(null);
			}
			
			rs.close();
			ps.close();
			con.close();
		}
		catch(SQLException ex) {
			ex.printStackTrace();
		}
		return renter;
	}
	
	public boolean icValidate(String ic) {
		boolean found = false;
		
		try {
			con = ConnectionManager.getConnection();

			ps = con.prepareStatement(
					"SELECT * "
					+ "FROM RENTER "
					+ "WHERE RENTER_IC LIKE ?"
				);
			
			ps.setString(1, ic);
			rs = ps.executeQuery();
			
			if(rs.next()) found = true;
			
			rs.close();
			ps.close();
			con.close();
		}
		catch(SQLException ex) {
			ex.printStackTrace();
		}
		return !found;
	}
	
	public boolean emailValidate(String email) {
		boolean found = false;
		
		try {
			con = ConnectionManager.getConnection();

			ps = con.prepareStatement(
					"SELECT * "
					+ "FROM RENTER "
					+ "WHERE RENTER_EMAIL LIKE ?"
				);
			
			ps.setString(1, email);
			rs = ps.executeQuery();
			
			if(rs.next()) found = true;
			
			rs.close();
			ps.close();
			con.close();
		}
		catch(SQLException ex) {
			ex.printStackTrace();
		}
		return !found;
	}
	
	public static RenterBean getRenterByIc(String ic) throws IOException {
		RenterBean renter = null;
		
		try {
			con = ConnectionManager.getConnection();

			ps = con.prepareStatement(
					"SELECT * "
					+ "FROM RENTER "
					+ "WHERE RENTER_IC LIKE ?"
				);
			
			ps.setString(1, ic);
			rs = ps.executeQuery();
			
			if(rs.next()) {
				renter = new RenterBean();
				
				renter.setIc(rs.getString("RENTER_IC"));
				renter.setName(rs.getString("RENTER_NAME"));
				renter.setEmail(rs.getString("RENTER_EMAIL"));
				renter.setAddress(rs.getString("RENTER_ADDRESS"));
				renter.setPhoneNumber(rs.getString("RENTER_PHONENUMBER"));
				renter.setPassword(rs.getString("RENTER_PASSWORD"));
				renter.setGender(rs.getString("RENTER_GENDER"));
				
				Blob blob = rs.getBlob("RENTER_IMAGE");
				if(blob != null) 
					renter.setImage(blob.getBytes(1, (int)blob.length()));
				else
					renter.setImage(null);
			}
			
			rs.close();
			ps.close();
			con.close();
		}
		catch(SQLException ex) {
			ex.printStackTrace();
		}
		return renter;
	}
}
