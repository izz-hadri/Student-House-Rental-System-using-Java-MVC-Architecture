package rental.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import rental.connection.ConnectionManager;
import rental.model.LandlordBean;

public class LandlordDAO {
	static Connection con = null;
	static ResultSet rs = null;
	static PreparedStatement ps = null;
	static Statement stmt = null;
	
	static String ic, name, email, phoneNumber, password, accountNumber, bankName;
	
	public static LandlordBean getLandlordByHouseId(int houseId) {
		LandlordBean landlord = null;
		
		try {
			con = ConnectionManager.getConnection();

			ps = con.prepareStatement(
					"SELECT * FROM LANDLORD "
					+ "JOIN HOUSE "
					+ "USING (LANDLORD_IC) "
					+ "WHERE HOUSE_ID=?"
				);
			
			ps.setInt(1, houseId);
			rs = ps.executeQuery();
			
			if(rs.next()) {
				landlord = new LandlordBean();
				
				landlord.setIc(rs.getString("LANDLORD_IC"));
				landlord.setName(rs.getString("LANDLORD_NAME"));
				landlord.setEmail(rs.getString("LANDLORD_EMAIL"));
				landlord.setPhoneNumber(rs.getString("LANDLORD_PHONENUMBER"));
				landlord.setPassword(rs.getString("LANDLORD_PASSWORD"));
				landlord.setAccountNumber(rs.getString("LANDLORD_ACCOUNTNUMBER"));
				landlord.setBankName(rs.getString("LANDLORD_BANKNAME"));
			}
			
			rs.close();
			ps.close();
			con.close();
		}
		catch(SQLException ex) {
			ex.printStackTrace();
		}
		return landlord;
	}
	
	public LandlordBean login(String ic, String password) {
		LandlordBean landlord = null;
		
		try {
			con = ConnectionManager.getConnection();

			ps = con.prepareStatement(
					"SELECT * FROM LANDLORD WHERE LANDLORD_IC = ? AND LANDLORD_PASSWORD=?"
					);
			ps.setString(1, ic);
			ps.setString(2, password);
			rs = ps.executeQuery();

			if(rs.next()) {
				landlord = new LandlordBean();
				
				landlord.setIc(rs.getString("LANDLORD_IC"));
				landlord.setName(rs.getString("LANDLORD_NAME"));
				landlord.setEmail(rs.getString("LANDLORD_EMAIL"));
				landlord.setPhoneNumber(rs.getString("LANDLORD_PHONENUMBER"));
				landlord.setPassword(rs.getString("LANDLORD_PASSWORD"));
				landlord.setAccountNumber(rs.getString("LANDLORD_ACCOUNTNUMBER"));
				landlord.setBankName(rs.getString("LANDLORD_BANKNAME"));
			}			
		}catch(SQLException ex) {
			ex.printStackTrace();
		}finally {
			if (ps != null) {
				try {
					ps.close();
				} catch (Exception e) {
				}
				ps = null;
			}
			if (con != null) {
				try {
					con.close();
				} catch (Exception e) {
				}
				con = null;
			}
		}
		return landlord;
	}
	
	public boolean icValidate(String ic) {
		boolean found = false;
		
		try {
			con = ConnectionManager.getConnection();

			ps = con.prepareStatement(
					"SELECT * FROM LANDLORD WHERE LANDLORD_IC = ?"
				);
			
			ps.setString(1, ic);
			rs = ps.executeQuery();
			
			if(rs.next()) found = true;
			
			rs.close();
			ps.close();
			con.close();
		}
		catch(SQLException ex) {
			ex.printStackTrace();
		}
		return !found;
	}
	
	public boolean emailValidate(String email) {
		boolean found = false;
		
		try {
			con = ConnectionManager.getConnection();

			ps = con.prepareStatement(
					"SELECT * FROM LANDLORD WHERE LANDLORD_EMAIL = ?"
				);
			
			ps.setString(1, email);
			rs = ps.executeQuery();
			
			if(rs.next()) found = true;
			
			rs.close();
			ps.close();
			con.close();
		}
		catch(SQLException ex) {
			ex.printStackTrace();
		}
		return !found;
	}
	
	public void add(LandlordBean landlord) {
		ic = landlord.getIc();
		name = landlord.getName();
		email = landlord.getEmail();
		phoneNumber = landlord.getPhoneNumber();
		password = landlord.getPassword();

		try {
			con = ConnectionManager.getConnection();
			ps=con.prepareStatement("INSERT INTO LANDLORD(LANDLORD_IC,LANDLORD_NAME,LANDLORD_EMAIL,LANDLORD_PHONENUMBER,"
					+ "LANDLORD_PASSWORD)VALUES(?,?,?,?,?)");
			ps.setString(1,ic);
			ps.setString(2,name);
			ps.setString(3,email);
			ps.setString(4,phoneNumber);
			ps.setString(5,password);
			ps.executeUpdate();

		}catch (Exception ex) {
			ex.printStackTrace();
		}finally {
			if (ps != null) {
				try {
					ps.close();
				} catch (Exception e) {
				}
				ps = null;
			}
			if (con != null) {
				try {
					con.close();
				} catch (Exception e) {
				}
				con = null;
			}
		}
	}
	
	public static LandlordBean getLandlordByIc(String ic) {
		LandlordBean landlord = null;
		
		try {
			con = ConnectionManager.getConnection();

			ps = con.prepareStatement(
					"SELECT * "
					+ "FROM LANDLORD "
					+ "WHERE LANDLORD_IC=?"
				);
			
			ps.setString(1, ic);
			rs = ps.executeQuery();
			
			if(rs.next()) {
				landlord = new LandlordBean();
				
				landlord.setIc(rs.getString("LANDLORD_IC"));
				landlord.setName(rs.getString("LANDLORD_NAME"));
				landlord.setEmail(rs.getString("LANDLORD_EMAIL"));
				landlord.setPhoneNumber(rs.getString("LANDLORD_PHONENUMBER"));
				landlord.setPassword(rs.getString("LANDLORD_PASSWORD"));
				landlord.setAccountNumber(rs.getString("LANDLORD_ACCOUNTNUMBER"));
				landlord.setBankName(rs.getString("LANDLORD_BANKNAME"));
			}
			
			rs.close();
			ps.close();
			con.close();
		}
		catch(SQLException ex) {
			ex.printStackTrace();
		}
		return landlord;
	}
	
	public boolean update(LandlordBean landlord){
		ic = landlord.getIc();
		name = landlord.getName();
		email = landlord.getEmail();
		phoneNumber = landlord.getPhoneNumber();
		password = landlord.getPassword();
		accountNumber = landlord.getAccountNumber();
		bankName = landlord.getBankName();
		
		try {
			con = ConnectionManager.getConnection();

			ps = con.prepareStatement(
					"UPDATE LANDLORD SET LANDLORD_NAME=?, LANDLORD_EMAIL=?, LANDLORD_PASSWORD=?, LANDLORD_ACCOUNTNUMBER=?, LANDLORD_BANKNAME=?, LANDLORD_PHONENUMBER=? WHERE LANDLORD_IC=?"
				);
			
			ps.setString(1, name);
			ps.setString(2, email);
			ps.setString(3, password);
			ps.setString(4, accountNumber);
			ps.setString(5, bankName);
			ps.setString(6, phoneNumber);
			ps.setString(7, ic);
			int count = ps.executeUpdate();
			if(count > 0) {
				System.out.println("SQL SUCCESS TO BE SET");
				return true;
			}else {
				System.out.println("SQL FAILED TO BE SET");
				return false;
			}
		}catch(SQLException ex) {
			ex.printStackTrace();
			return false;
		}finally {
			if (ps != null) {
				try {
					ps.close();
				} catch (Exception e) {
				}
				ps = null;
			}
			if (con != null) {
				try {
					con.close();
				} catch (Exception e) {
				}
				con = null;
			}
		}
	}
}
