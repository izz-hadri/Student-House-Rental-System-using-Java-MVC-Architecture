package rental.dao;

import java.io.IOException;
import java.io.InputStream;
import java.sql.Blob;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.LinkedList;
import java.util.List;

import rental.connection.ConnectionManager;
import rental.model.HouseBean;

public class HouseDAO {
	static Connection con = null;
	static ResultSet rs = null;
	static PreparedStatement ps = null;
	static Statement stmt = null;
	
	static int id, contract, capacity;
	static String address, area, description, landlordIc;
	static double price;
	static byte[] image;
	
	public static List<HouseBean> getAllHouse(String ic) {
		List<HouseBean> houses = new LinkedList<HouseBean>();
		
		try {
			con = ConnectionManager.getConnection();

			ps = con.prepareStatement(
					"SELECT * "
					+ "FROM HOUSE "
					+ "WHERE HOUSE_ID != ALL   (SELECT H.HOUSE_ID "
					+ "							FROM HOUSE H "
					+ "							LEFT OUTER JOIN RENTAL R "
					+ "							ON H.HOUSE_ID = R.HOUSE_ID "
					+ "							WHERE RENTAL_STATUS LIKE 'Rented' "
					+ "							AND RENTAL_EXPIRED_DATE > SYSDATE) "
					+ "AND HOUSE_ID != ALL     (SELECT H.HOUSE_ID "
					+ "							FROM HOUSE H "
					+ "							LEFT OUTER JOIN RENTAL R "
					+ "							ON H.HOUSE_ID = R.HOUSE_ID "
					+ "							WHERE RENTAL_STATUS LIKE 'Pending' "
					+ "							AND RENTER_IC LIKE ?) "
					+ "ORDER BY HOUSE_PRICE DESC"
				);
			
			ps.setString(1, ic);
			rs = ps.executeQuery();
			
			while(rs.next()) {
				HouseBean house = new HouseBean();
				
				house.setId(rs.getInt("HOUSE_ID"));
				house.setAddress(rs.getString("HOUSE_ADDRESS"));
				house.setArea(rs.getString("HOUSE_AREA"));
				house.setPrice(rs.getDouble("HOUSE_PRICE"));
				house.setContract(rs.getInt("HOUSE_CONTRACT"));
				house.setCapacity(rs.getInt("HOUSE_CAPACITY"));
				house.setDescription(rs.getString("HOUSE_DESCRIPTION"));
				house.setLandlordIc(rs.getString("LANDLORD_IC"));
				
				Blob blob = rs.getBlob("HOUSE_IMAGE");
				if(blob != null) 
					house.setImage(blob.getBytes(1, (int)blob.length()));
				else
					house.setImage(null);
				
				houses.add(house);
			}
			
			rs.close();
			ps.close();
			con.close();
		}
		catch(SQLException ex) {
			ex.printStackTrace();
		}
		return houses;
	}
	
	public static HouseBean getHouseById(int id) throws IOException {
		HouseBean house = null;
		
		try {
			con = ConnectionManager.getConnection();

			ps = con.prepareStatement(
					"SELECT * FROM HOUSE "
					+ "WHERE HOUSE_ID=?"
				);
			
			ps.setInt(1, id);
			rs = ps.executeQuery();
			
			if(rs.next()) {
				house = new HouseBean();
			
				house.setId(rs.getInt("HOUSE_ID"));
				house.setAddress(rs.getString("HOUSE_ADDRESS"));
				house.setArea(rs.getString("HOUSE_AREA"));
				house.setPrice(rs.getDouble("HOUSE_PRICE"));
				house.setContract(rs.getInt("HOUSE_CONTRACT"));
				house.setCapacity(rs.getInt("HOUSE_CAPACITY"));
				house.setDescription(rs.getString("HOUSE_DESCRIPTION"));
				house.setLandlordIc(rs.getString("LANDLORD_IC"));
				
				Blob blob = rs.getBlob("HOUSE_IMAGE");
				if(blob != null) 
					house.setImage(blob.getBytes(1, (int)blob.length()));
				else
					house.setImage(null);
			}
			
			rs.close();
			ps.close();
			con.close();
		}
		catch(SQLException ex) {
			ex.printStackTrace();
		}
		return house;
	}
	
	public static List<HouseBean> getAllHouseFilter(String ic, String[] facilities, String sortPrice) {
		List<HouseBean> houses = new LinkedList<HouseBean>();
		
		try {
			con = ConnectionManager.getConnection();
			
			String sql = "SELECT * "
						+ "FROM HOUSE "
						+ "WHERE HOUSE_ID != ALL   (SELECT H.HOUSE_ID "
						+ "							FROM HOUSE H "
						+ "							LEFT OUTER JOIN RENTAL R "
						+ "							ON H.HOUSE_ID = R.HOUSE_ID "
						+ "							WHERE RENTAL_STATUS LIKE 'Rented' "
						+ "							AND RENTAL_EXPIRED_DATE > SYSDATE) "
						+ "AND HOUSE_ID != ALL     (SELECT H.HOUSE_ID "
						+ "							FROM HOUSE H "
						+ "							LEFT OUTER JOIN RENTAL R "
						+ "							ON H.HOUSE_ID = R.HOUSE_ID "
						+ "							WHERE RENTAL_STATUS LIKE 'Pending' "
						+ "							AND RENTER_IC LIKE ?) ";
			
			if(facilities != null) {
				sql += "AND HOUSE_ID = ANY     (SELECT H.HOUSE_ID "
						+ "						FROM HOUSE H "
						+ "						LEFT OUTER JOIN FACILITY F "
						+ "						ON H.HOUSE_ID = F.HOUSE_ID "
						+ "						WHERE ";
				
				for(int i=0; i<facilities.length; i++) {
					if(i == 0)
						sql += "FACILITY_NAME LIKE ? ";
					else
						sql += "AND FACILITY_NAME LIKE ? ";
				}
				sql += ") ";
			}
			
			if(sortPrice.equals("highestPrice"))
				sql += "ORDER BY HOUSE_PRICE DESC";
			else
				sql += "ORDER BY HOUSE_PRICE ASC";
			
			ps = con.prepareStatement(sql);
			
			ps.setString(1, ic);
			if(facilities != null) for(int i=0; i<facilities.length; i++) ps.setString(i+2, facilities[i]);
			rs = ps.executeQuery();
			
			while(rs.next()) {
				HouseBean house = new HouseBean();
				
				house.setId(rs.getInt("HOUSE_ID"));
				house.setAddress(rs.getString("HOUSE_ADDRESS"));
				house.setArea(rs.getString("HOUSE_AREA"));
				house.setPrice(rs.getDouble("HOUSE_PRICE"));
				house.setContract(rs.getInt("HOUSE_CONTRACT"));
				house.setCapacity(rs.getInt("HOUSE_CAPACITY"));
				house.setDescription(rs.getString("HOUSE_DESCRIPTION"));
				house.setLandlordIc(rs.getString("LANDLORD_IC"));
				
				Blob blob = rs.getBlob("HOUSE_IMAGE");
				if(blob != null) 
					house.setImage(blob.getBytes(1, (int)blob.length()));
				else
					house.setImage(null);
				
				houses.add(house);
			}
			
			rs.close();
			ps.close();
			con.close();
		}
		catch(SQLException ex) {
			ex.printStackTrace();
		}
		return houses;
	}
	
	public static List<HouseBean> getAllHouseByLandlordIc(String ic) {
		List<HouseBean> houses = new LinkedList<HouseBean>();
		
		try {
			con = ConnectionManager.getConnection();

			ps = con.prepareStatement(
					"SELECT * "
					+ "FROM HOUSE "
					+ "WHERE LANDLORD_IC=? "
				);
			
			ps.setString(1, ic);
			rs = ps.executeQuery();
			
			while(rs.next()) {
				HouseBean house = new HouseBean();
				
				house.setId(rs.getInt("HOUSE_ID"));
				house.setAddress(rs.getString("HOUSE_ADDRESS"));
				house.setArea(rs.getString("HOUSE_AREA"));
				house.setPrice(rs.getDouble("HOUSE_PRICE"));
				house.setContract(rs.getInt("HOUSE_CONTRACT"));
				house.setCapacity(rs.getInt("HOUSE_CAPACITY"));
				house.setDescription(rs.getString("HOUSE_DESCRIPTION"));
				house.setLandlordIc(rs.getString("LANDLORD_IC"));
				
				Blob blob = rs.getBlob("HOUSE_IMAGE");
				if(blob != null) 
					house.setImage(blob.getBytes(1, (int)blob.length()));
				else
					house.setImage(null);
				
				houses.add(house);
			}
			
			rs.close();
			ps.close();
			con.close();
		}
		catch(SQLException ex) {
			ex.printStackTrace();
		}
		return houses;
	}
	
	public void add(HouseBean house, InputStream image){
		contract = house.getContract();
		capacity = house.getCapacity();
		address = house.getAddress();
		area = house.getArea();
		description = house.getDescription();
		landlordIc = house.getLandlordIc();
		price = house.getPrice();
		
		try {
			con = ConnectionManager.getConnection();
			
			ps = con.prepareStatement(
					"INSERT INTO HOUSE ( HOUSE_ADDRESS, HOUSE_AREA, HOUSE_PRICE, HOUSE_CONTRACT, HOUSE_CAPACITY, HOUSE_DESCRIPTION, LANDLORD_IC, HOUSE_IMAGE) VALUES(?,?,?,?,?,?,?,?)");

			ps.setString(1, address);
			ps.setString(2, area);
			ps.setFloat(3, (float) price);
			ps.setInt(4, contract);
			ps.setInt(5, capacity);
			ps.setString(6, description);
			ps.setString(7, landlordIc);
			ps.setBlob(8, image);
			ps.executeUpdate();
		}
		catch(SQLException ex) {
			ex.printStackTrace();
		}
		finally {
			if (ps != null) {
				try {
					ps.close();
				} catch (Exception e) {
				}
				ps = null;
			}
			if (con != null) {
				try {
					con.close();
				} catch (Exception e) {
				}
				con = null;
			}
		}
	}
	
	public boolean checkHouseIsRented(int id) {
		boolean found = false;
		
		try {
			con = ConnectionManager.getConnection();

			ps = con.prepareStatement(
					"SELECT * "
					+ "FROM HOUSE "
					+ "WHERE HOUSE_ID = ANY   (SELECT H.HOUSE_ID "
					+ "							FROM HOUSE H "
					+ "							LEFT OUTER JOIN RENTAL R "
					+ "							ON H.HOUSE_ID = R.HOUSE_ID "
					+ "							WHERE RENTAL_STATUS LIKE 'Rented' "
					+ "							AND RENTAL_EXPIRED_DATE > SYSDATE) "
					+ "AND HOUSE_ID = ANY     (SELECT H.HOUSE_ID "
					+ "							FROM HOUSE H "
					+ "							LEFT OUTER JOIN RENTAL R "
					+ "							ON H.HOUSE_ID = R.HOUSE_ID "
					+ "							WHERE RENTAL_STATUS LIKE 'Pending') "
					+ "AND HOUSE_ID = ?"
				);
			
			ps.setInt(1, id);
			rs = ps.executeQuery();
			
			if(rs.next()) found = true;
			
			rs.close();
			ps.close();
			con.close();
		}
		catch(SQLException ex) {
			ex.printStackTrace();
		}
		return found;
	}
	
	public void delete(int id) {
		try {
			con = ConnectionManager.getConnection();
			
			//Delete all facility belong to the house
			ps = con.prepareStatement(
					"DELETE FACILITY WHERE HOUSE_ID=?"
				);
			
			ps.setInt(1, id);
			ps.executeUpdate();
			
			//Delete the house
			ps = con.prepareStatement(
					"DELETE HOUSE WHERE HOUSE_ID=?"
				);
			
			ps.setInt(1, id);
			ps.executeUpdate();
			
			ps.close();
			con.close();
		}
		catch(SQLException ex) {
			ex.printStackTrace();
		}
	}
	
	public void update(HouseBean bean) {
		id = bean.getId();
		contract = bean.getContract();
		capacity= bean.getCapacity();
		address = bean.getAddress();
		area = bean.getArea();
		description = bean.getDescription();
		price = bean.getPrice();

		try {
			con = ConnectionManager.getConnection();

			ps = con.prepareStatement(
					"UPDATE HOUSE "
					+ "SET HOUSE_ADDRESS=?, HOUSE_AREA=?, HOUSE_PRICE=?, HOUSE_CONTRACT=?, HOUSE_CAPACITY=?, HOUSE_DESCRIPTION=?"
					+ "WHERE HOUSE_ID=?"
				);
			
			ps.setString(1, address);
			ps.setString(2, area);
			ps.setFloat(3, (float) price);
			ps.setInt(4, contract);
			ps.setInt(5, capacity);
			ps.setString(6, description);
			ps.setInt(7, id);
			ps.executeUpdate();
			
			ps.close();
			con.close();
		}
		catch(SQLException ex) {
			ex.printStackTrace();
		}
	}
	
}
