package rental.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.LinkedList;
import java.util.List;

import rental.connection.ConnectionManager;
import rental.model.PaymentBean;

public class PaymentDAO {
	static Connection con = null;
	static ResultSet rs = null;
	static ResultSet rs2 = null;
	static PreparedStatement ps = null;
	static PreparedStatement ps2 = null;
	static Statement stmt = null;
	
	public static List<PaymentBean> getPaymentList(int paymentId) {
		List<PaymentBean> payments = new LinkedList<PaymentBean>();
		int status=0;
		try {
			con = ConnectionManager.getConnection();
			ps = con.prepareStatement(
					"SELECT * "+					
					"FROM PAYMENT "+
					"WHERE PAYMENT_ID=? "+
					"ORDER BY STATUS ASC"
			);
			ps.setInt(1, paymentId);
			rs = ps.executeQuery();
			
			while(rs.next()) {
				PaymentBean payment = new PaymentBean();
				status=rs.getInt("STATUS");
				payment.setHouseId(rs.getInt("HOUSE_ID"));
				payment.setLandLordIc(rs.getString("LANDLORD_IC"));
				payment.setPaymentId(rs.getInt("PAYMENT_ID"));
				payment.setRenterIc("RENTER_IC");
				payment.setHouseId(rs.getInt("HOUSE_ID"));
				payment.setPaymentDate(rs.getDate("PAYMENT_DATE"));
				payment.setPrice(rs.getFloat("PAYMENT_PRICE"));
				if(status==1) {
					payment.setStatus("PAID");
				}else {
					payment.setStatus("NOT PAID");
				}
				payments.add(payment);
			}
		}
		catch(SQLException ex) {
			ex.printStackTrace();
		}finally {
			if (ps != null) {
				try {
					ps.close();
				} catch (Exception e) {
				}
				ps = null;
			}
			if (con != null) {
				try {
					con.close();
				} catch (Exception e) {
				}
				con = null;
			}
		}
		return payments;
	}

	public boolean verifyPayment(String ric, String hid, String pid) {
		boolean result=false;
		int count = 0;
		try {
			con = ConnectionManager.getConnection();

			ps = con.prepareStatement(
					"UPDATE PAYMENT "
							+ "SET STATUS=1"
							+ "WHERE PAYMENT_ID=?"
					);

			ps.setString(1, pid);
			count=ps.executeUpdate();
			if(count>0) {
				result=true;
			}

		}catch(SQLException ex) {
			ex.printStackTrace();
		}finally {
			if (ps != null) {
				try {
					ps.close();

				} catch (Exception e) {
				}
				ps = null;

			}
			if (con != null) {
				try {
					con.close();
				} catch (Exception e) {
				}
				con = null;
			}
		}
		return result;
	}

	public boolean addPaymentDate(PaymentBean bean) {
		int count=0;
		boolean result=false;
		System.out.println(bean.getPrice());
		System.out.println(bean.getRenterIc());
		System.out.println(bean.getLandLordIc());
		
		try {
			con = ConnectionManager.getConnection();
			ps = con.prepareStatement(
					"INSERT INTO PAYMENT(PAYMENT_PRICE,RENTER_IC,LANDLORD_IC,HOUSE_ID,STATUS) VALUES(?,?,?,?,?)"
					);
			ps.setFloat(1, (float) bean.getPrice());
			ps.setString(2,bean.getRenterIc());
			ps.setString(3,bean.getLandLordIc());
			ps.setInt(4,bean.getHouseId());
			ps.setString(5, "0");
			count=ps.executeUpdate();
			
			if(count>0) {
				result=true;
				System.out.println("PAYMENT INSERT SUCCESS");
			}else {
				System.out.println("PAYMENT INSERT FAILED");
			}
		}catch(SQLException ex) {
			ex.printStackTrace();
		}finally {
			if (ps != null) {
				try {
					ps.close();

				} catch (Exception e) {
				}
				ps = null;

			}
			if (con != null) {
				try {
					con.close();
				} catch (Exception e) {
				}
				con = null;
			}
		}
		return result;
	}

	public void selectPayment(String paymentId,PaymentBean bean) {
		int status=0;
		try {
			con = ConnectionManager.getConnection();
			ps = con.prepareStatement(
					"SELECT * FROM PAYMENT WHERE PAYMENT_ID=?"
					);
			ps.setInt(1, Integer.parseInt(paymentId));
			rs=ps.executeQuery();
			if(rs.next()) {
				bean.setLandLordIc(rs.getString("LANDLORD_IC"));
				bean.setHouseId(rs.getInt("HOUSE_ID"));
				bean.setPaymentDate(rs.getDate("PAYMENT_DATE"));
				bean.setPaymentId(rs.getInt("PAYMENT_ID"));
				bean.setPrice(rs.getInt("PAYMENT_PRICE"));
				bean.setRenterIc(rs.getString("RENTER_IC"));
				status=(rs.getInt("STATUS"));
				if(status==1) {
					bean.setStatus("PAID");
				}else {
					bean.setStatus("NOT PAID");
				}
			}
		}catch(SQLException ex) {
			ex.printStackTrace();
		}finally {
			if (ps != null) {
				try {
					ps.close();

				} catch (Exception e) {
				}
				ps = null;

			}
			if (con != null) {
				try {
					con.close();
				} catch (Exception e) {
				}
				con = null;
			}
		}
	}


}
