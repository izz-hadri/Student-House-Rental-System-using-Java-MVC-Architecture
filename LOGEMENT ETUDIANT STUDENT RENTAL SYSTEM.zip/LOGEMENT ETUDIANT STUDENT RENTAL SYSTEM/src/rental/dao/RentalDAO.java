package rental.dao;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Date;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;

import rental.connection.ConnectionManager;
import rental.model.RentalBean;

public class RentalDAO {
	static Connection con = null;
	static ResultSet rs = null;
	static PreparedStatement ps = null;
	static Statement stmt = null;
	
	static int id, houseId;
	static Date registerDate, expiredDate;
	static String status, renterIc;
	
	public void add(RentalBean bean) {
		registerDate = bean.getRegisterDate();
		expiredDate = bean.getExpiredDate();
		status = bean.getStatus();
		renterIc = bean.getRenterIc();
		houseId = bean.getHouseId();
		
		try {
			con = ConnectionManager.getConnection();

			ps = con.prepareStatement(
					"INSERT INTO RENTAL(RENTAL_REGISTER_DATE, RENTAL_EXPIRED_DATE, RENTAL_STATUS, RENTER_IC, HOUSE_ID) "
					+ "VALUES(?,?,?,?,?)"
				);
			
			ps.setDate(1, new java.sql.Date(registerDate.getTime()));
			ps.setDate(2, new java.sql.Date(expiredDate.getTime()));
			ps.setString(3, status);
			ps.setString(4, renterIc);
			ps.setInt(5, houseId);
			ps.executeUpdate();
			
			ps.close();
			con.close();
		}
		catch(SQLException ex) {
			ex.printStackTrace();
		}
	}
	
	public static List<RentalBean> getRentalByRenterIc(String renterIc) {
		List<RentalBean> rentals = new LinkedList<RentalBean>();
		
		try {
			con = ConnectionManager.getConnection();

			ps = con.prepareStatement(
					"SELECT * "
					+ "FROM RENTAL "
					+ "WHERE RENTER_IC LIKE ? "
					+ "AND ((RENTAL_STATUS LIKE 'Rented' "
					+ "AND RENTAL_EXPIRED_DATE > SYSDATE) "
					+ "OR RENTAL_STATUS LIKE 'Pending') "
					+ "ORDER BY HOUSE_ID ASC"
				);
			
			ps.setString(1, renterIc);
			rs = ps.executeQuery();
			
			while(rs.next()) {
				RentalBean rental = new RentalBean();
				
				rental.setId(rs.getInt("RENTAL_ID"));
				rental.setRegisterDate(rs.getDate("RENTAL_REGISTER_DATE"));
				rental.setExpiredDate(rs.getDate("RENTAL_EXPIRED_DATE"));
				rental.setStatus(rs.getString("RENTAL_STATUS"));
				rental.setRenterIc(rs.getString("RENTER_IC"));
				rental.setHouseId(rs.getInt("HOUSE_ID"));
				
				rentals.add(rental);
			}
			
			rs.close();
			ps.close();
			con.close();
		}
		catch(SQLException ex) {
			ex.printStackTrace();
		}
		return rentals;
	}
	
	public static RentalBean getRentalById(int id) {
		RentalBean rental = null;
		
		try {
			con = ConnectionManager.getConnection();

			ps = con.prepareStatement(
					"SELECT * "
					+ "FROM RENTAL "
					+ "WHERE RENTAL_ID=?"
				);
			ps.setInt(1, id);
			rs = ps.executeQuery();
			
			if(rs.next()) {
				rental = new RentalBean();
				
				rental.setId(rs.getInt("RENTAL_ID"));
				rental.setRegisterDate(rs.getDate("RENTAL_REGISTER_DATE"));
				rental.setExpiredDate(rs.getDate("RENTAL_EXPIRED_DATE"));
				rental.setStatus(rs.getString("RENTAL_STATUS"));
				rental.setRenterIc(rs.getString("RENTER_IC"));
				rental.setHouseId(rs.getInt("HOUSE_ID"));
			}
			
			rs.close();
			ps.close();
			con.close();
		}
		catch(SQLException ex) {
			ex.printStackTrace();
		}
		return rental;
	}
	
	public void update(Date expiredDate, int id) {
		try {
			con = ConnectionManager.getConnection();

			ps = con.prepareStatement(
					"UPDATE RENTAL "
					+ "SET RENTAL_EXPIRED_DATE=? "
					+ "WHERE RENTAL_ID=?"
				);
			
			ps.setDate(1, new java.sql.Date(expiredDate.getTime()));
			ps.setInt(2, id);
			ps.executeUpdate();
			
			ps.close();
			con.close();
		}
		catch(SQLException ex) {
			ex.printStackTrace();
		}
	}

	public void delete(int rentalId) {
		try {
			con = ConnectionManager.getConnection();

			ps = con.prepareStatement(
					"DELETE FROM RENTAL "
					+ "WHERE RENTAL_ID=?"
				);
			
			ps.setInt(1, rentalId);
			ps.executeUpdate();
			
			ps.close();
			con.close();
		}
		catch(SQLException ex) {
			ex.printStackTrace();
		}
	}
	
	public static List<RentalBean> getAllRentalPendingByLandlordIc(String landlordIc) throws IOException {
		 List<RentalBean> rentals = new LinkedList<RentalBean>();
		
		try {
			con = ConnectionManager.getConnection();

			ps = con.prepareStatement(
					"SELECT * "
					+ "FROM RENTAL "
					+ "JOIN HOUSE "
					+ "USING (HOUSE_ID) "
					+ "WHERE LANDLORD_IC LIKE ? "
					+ "AND HOUSE_ID = ANY  (SELECT H.HOUSE_ID FROM HOUSE H LEFT OUTER JOIN RENTAL R ON H.HOUSE_ID = R.HOUSE_ID  WHERE RENTAL_STATUS LIKE 'Pending')"
				);
			
			ps.setString(1, landlordIc);
			rs = ps.executeQuery();
			
			while(rs.next()) {
				RentalBean rental = new RentalBean();
				
				rental.setId(rs.getInt("RENTAL_ID"));
				rental.setRegisterDate(rs.getDate("RENTAL_REGISTER_DATE"));
				rental.setExpiredDate(rs.getDate("RENTAL_EXPIRED_DATE"));
				rental.setStatus(rs.getString("RENTAL_STATUS"));
				rental.setRenterIc(rs.getString("RENTER_IC"));
				rental.setHouseId(rs.getInt("HOUSE_ID"));
				
				rentals.add(rental);
			}
			
			rs.close();
			ps.close();
			con.close();
		}
		catch(SQLException ex) {
			ex.printStackTrace();
		}
		return rentals;
	}
	
	public static List<RentalBean> getAllRentalRentedByLandlordIc(String landlordIc) throws IOException {
		 List<RentalBean> rentals = new LinkedList<RentalBean>();
		
		try {
			con = ConnectionManager.getConnection();

			ps = con.prepareStatement(
					"SELECT * "
					+ "FROM RENTAL "
					+ "JOIN HOUSE "
					+ "USING (HOUSE_ID) "
					+ "WHERE LANDLORD_IC LIKE ? "
					+ "AND HOUSE_ID = ANY  (SELECT H.HOUSE_ID FROM HOUSE H LEFT OUTER JOIN RENTAL R ON H.HOUSE_ID = R.HOUSE_ID WHERE RENTAL_STATUS LIKE 'Rented' AND RENTAL_EXPIRED_DATE > SYSDATE)"
				);
			
			ps.setString(1, landlordIc);
			rs = ps.executeQuery();
			
			while(rs.next()) {
				RentalBean rental = new RentalBean();
				
				rental.setId(rs.getInt("RENTAL_ID"));
				rental.setRegisterDate(rs.getDate("RENTAL_REGISTER_DATE"));
				rental.setExpiredDate(rs.getDate("RENTAL_EXPIRED_DATE"));
				rental.setStatus(rs.getString("RENTAL_STATUS"));
				rental.setRenterIc(rs.getString("RENTER_IC"));
				rental.setHouseId(rs.getInt("HOUSE_ID"));
				
				rentals.add(rental);
			}
			
			rs.close();
			ps.close();
			con.close();
		}
		catch(SQLException ex) {
			ex.printStackTrace();
		}
		return rentals;
	}
	
	public void approve(int id) {
		try {
			con = ConnectionManager.getConnection();

			ps = con.prepareStatement(
					"UPDATE RENTAL "
					+ "SET RENTAL_STATUS=? "
					+ "WHERE RENTAL_ID=?"
				);
			
			ps.setString(1, "Rented");
			ps.setInt(2, id);
			ps.executeUpdate();
			
			ps.close();
			con.close();
		}
		catch(SQLException ex) {
			ex.printStackTrace();
		}
	}
	
	public boolean validateApprove(int houseId) {
		boolean found = false;
		
		try {
			con = ConnectionManager.getConnection();

			ps = con.prepareStatement(
					"SELECT * "
					+ "FROM HOUSE "
					+ "WHERE HOUSE_ID = ANY   (SELECT H.HOUSE_ID "
					+ "							FROM HOUSE H "
					+ "							LEFT OUTER JOIN RENTAL R "
					+ "							ON H.HOUSE_ID = R.HOUSE_ID "
					+ "							WHERE RENTAL_STATUS LIKE 'Rented' "
					+ "							AND RENTAL_EXPIRED_DATE > SYSDATE) "
					+ "AND HOUSE_ID LIKE ?"
				);
			
			ps.setInt(1, houseId);
			rs = ps.executeQuery();
			
			if(rs.next()) found = true;
			
			rs.close();
			ps.close();
			con.close();
		}
		catch(SQLException ex) {
			ex.printStackTrace();
		}
		return !found;
	}
	
	public static int getPaymentIdByRentalId(int rentalId) throws IOException {
		try {
			con = ConnectionManager.getConnection();

			ps = con.prepareStatement(
					"SELECT * "
					+ "FROM RENTAL "
					+ "JOIN HOUSE "
					+ "USING (HOUSE_ID) "
					+ "JOIN PAYMENT "
					+ "USING (HOUSE_ID) "
					+ "WHERE RENTAL_ID LIKE ? "
				);
			
			ps.setInt(1, rentalId);
			rs = ps.executeQuery();
			
			if(rs.next()) return rs.getInt("PAYMENT_ID");
			
			rs.close();
			ps.close();
			con.close();
		}
		catch(SQLException ex) {
			ex.printStackTrace();
		}
		return -1;
	}
	
	public static HashMap<String,Integer> getStatistic(String ic) {
		HashMap<String,Integer> stat = new HashMap<String,Integer>();
		
		try {
			con = ConnectionManager.getConnection();

			ps = con.prepareStatement(
					"SELECT COUNT(RENTAL_ID), HOUSE_AREA " 
					+"FROM RENTAL "
					+"JOIN HOUSE USING(HOUSE_ID) "
					+"WHERE RENTAL_STATUS LIKE 'Rented' "
					+ "AND LANDLORD_IC = ? "
					+"GROUP BY HOUSE_AREA"
				);
			
			ps.setString(1, ic);
			rs = ps.executeQuery();
			
			if(rs.next()) {
				stat.put(rs.getString(2), rs.getInt(1));
			}
			
			rs.close();
			ps.close();
			con.close();
		}
		catch(SQLException ex) {
			ex.printStackTrace();
		}
		return stat;
	}
}
