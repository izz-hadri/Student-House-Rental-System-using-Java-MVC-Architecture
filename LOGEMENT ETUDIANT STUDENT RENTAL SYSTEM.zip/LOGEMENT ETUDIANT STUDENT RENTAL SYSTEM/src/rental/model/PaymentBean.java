package rental.model;

import java.util.Date;

public class PaymentBean {
	private String status;
	private int paymentId;
	private int houseId;
	private String renterIc;
	private String landLordIc;
	private Date paymentDate;
	private double price;
	
	public String getLandLordIc() {
		return landLordIc;
	}
	
	public void setLandLordIc(String landLordIc) {
		this.landLordIc = landLordIc;
	}
	
	public int getPaymentId() {
		return paymentId;
	}
	
	public void setPaymentId(int paymentId) {
		this.paymentId = paymentId;
	}
	
	public String getRenterIc() {
		return renterIc;
	}
	
	public void setRenterIc(String renterIc) {
		this.renterIc = renterIc;
	}
	
	public String getStatus() {
		return status;
	}
	
	public void setStatus(String status) {
		this.status = status;
	}
	
	public int getHouseId() {
		return houseId;
	}
	
	public void setHouseId(int houseId) {
		this.houseId = houseId;
	}
	
	public Date getPaymentDate() {
		return paymentDate;
	}
	
	public void setPaymentDate(Date paymentDate) {
		this.paymentDate = paymentDate;
	}
	
	public double getPrice() {
		return price;
	}
	
	public void setPrice(double price) {
		this.price = price;
	}
}
