package rental.model;

public class RenterBean {
	private String ic;
	private String name;
	private String email;
	private String address; 
	private String phoneNumber;
	private String password;
	private String gender;
	private byte[] image;

	//Getter
	public String getIc() {
		return ic;
	}

	public String getName() {
		return name;
	}

	public String getEmail() {
		return email;
	}

	public String getAddress() {
		return address;
	}

	public String getPhoneNumber() {
		return phoneNumber;
	}

	public String getPassword() {
		return password;
	}
	
	public String getGender() {
		return gender;
	}

	public byte[] getImage() {
		return image;
	}

	//Setter
	public void setIc(String ic) {
		this.ic = ic;
	}

	public void setName(String name) {
		this.name = name;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public void setPhoneNumber(String phoneNumber) {
		this.phoneNumber = phoneNumber;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public void setGender(String gender) {
		this.gender = gender;
	}

	public void setImage(byte[] image) {
		this.image = image;
	}
}
