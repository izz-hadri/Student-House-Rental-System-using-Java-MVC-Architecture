package rental.model;

import java.util.Date;

public class RentalBean {
	private int id;
	private Date registerDate;
	private Date expiredDate;
	private String status;
	private String renterIc;
	private int houseId;
	
	//Getter
	public int getId() {
		return id;
	}
	
	public Date getRegisterDate() {
		return registerDate;
	}
	
	public Date getExpiredDate() {
		return expiredDate;
	}
	
	public String getStatus() {
		return status;
	}
	
	public String getRenterIc() {
		return renterIc;
	}
	
	public int getHouseId() {
		return houseId;
	}
	
	//Setter
	public void setId(int id) {
		this.id = id;
	}
	
	public void setRegisterDate(Date registerDate) {
		this.registerDate = registerDate;
	}
	
	public void setExpiredDate(Date expiredDate) {
		this.expiredDate = expiredDate;
	}
	
	public void setStatus(String status) {
		this.status = status;
	}
	
	public void setRenterIc(String renterIc) {
		this.renterIc = renterIc;
	}
	
	public void setHouseId(int houseId) {
		this.houseId = houseId;
	}
}
