package rental.model;

public class LandlordBean {

	private String ic;
	private String name;
	private String email;
	private String phoneNumber;
	private String password;
	private String accountNumber;
	private String bankName;
	
	//Getter
	public String getIc() {
		return ic;
	}
	
	public String getName() {
		return name;
	}
	
	public String getEmail() {
		return email;
	}
	
	public String getPhoneNumber() {
		return phoneNumber;
	}
	
	public String getPassword() {
		return password;
	}
	
	public String getAccountNumber() {
		return accountNumber;
	}
	
	public String getBankName() {
		return bankName;
	}
	
	//Setter
	public void setIc(String ic) {
		this.ic = ic;
	}
	
	public void setName(String name) {
		this.name = name;
	}
	
	public void setEmail(String email) {
		this.email = email;
	}
	
	public void setPhoneNumber(String phoneNumber) {
		this.phoneNumber = phoneNumber;
	}
	
	public void setPassword(String password) {
		this.password = password;
	}
	
	public void setAccountNumber(String accountNumber) {
		this.accountNumber = accountNumber;
	}
	
	public void setBankName(String bankName) {
		this.bankName = bankName;
	}
}
