package rental.model;

public class FacilityBean {

	private int id;
	private String name;
	private int quantity;
	private int houseId;
	
	//Getter
	public int getId() {
		return id;
	}
	
	public String getName() {
		return name;
	}
	
	public int getQuantity() {
		return quantity;
	}
	
	public int getHouseId() {
		return houseId;
	}
	
	//Setter
	public void setId(int id) {
		this.id = id;
	}
	
	public void setName(String name) {
		this.name = name;
	}
	
	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}
	
	public void setHouseId(int houseId) {
		this.houseId = houseId;
	}
}
