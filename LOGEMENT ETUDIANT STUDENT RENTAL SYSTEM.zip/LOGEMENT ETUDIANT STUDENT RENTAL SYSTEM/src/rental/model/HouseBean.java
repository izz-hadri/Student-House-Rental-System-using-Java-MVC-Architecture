package rental.model;

public class HouseBean {
	
	private int id;
	private String address;
	private String area;
	private double price;
	private int contract;
	private int capacity;
	private String description;
	private String landlordIc;
	private byte[] image;
	
	//Getter
	public int getId() {
		return id;
	}
	
	public String getAddress() {
		return address;
	}
	
	public String getArea() {
		return area;
	}
	
	public double getPrice() {
		return price;
	}
	
	public int getContract() {
		return contract;
	}
	
	public int getCapacity() {
		return capacity;
	}
	
	public String getDescription() {
		return description;
	}
	
	public String getLandlordIc() {
		return landlordIc;
	}

	public byte[] getImage() {
		return image;
	}
	
	//Setter
	public void setId(int id) {
		this.id = id;
	}
	
	public void setAddress(String address) {
		this.address = address;
	}
	
	public void setArea(String area) {
		this.area = area;
	}
	
	public void setPrice(double price) {
		this.price = price;
	}
	
	public void setContract(int contract) {
		this.contract = contract;
	}
	
	public void setCapacity(int capacity) {
		this.capacity = capacity;
	}
	
	public void setDescription(String description) {
		this.description = description;
	}
	
	public void setLandlordIc(String landlordIc) {
		this.landlordIc = landlordIc;
	}

	public void setImage(byte[] image) {
		this.image = image;
	}
}
